import '../../styles/header.css';

function TopBar() {
  return (
      <div className="row p-2 top_nav">
          <div className="col">
            <p className='medium'>50+ National Plastic Stores across India. Come, Visit Us!</p>
          </div>
        </div>
  )
}

export default TopBar
