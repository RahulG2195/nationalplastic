import "../../styles/investor.css";

function NationalFitness(){
  return (
        <div className="container">
            <div className="row NationalFitness-container">
                <h2>National <span>Finances</span></h2>
                <p>It is a long established fact that a reader will be distracted by the readable </p>
                <p>content of a page when looking at its layout.</p>
            </div>
        </div>
      
  );
}
export default NationalFitness;
