import { DEV_MIDDLEWARE_MANIFEST } from 'next/dist/shared/lib/constants'
import './Hirirng_Card.css'

const Hirirng_Card = (props) => {
    return (
        <>

            <div className="card-group d-flex justify-content-center {props.className}"  >
                <div className=" HiringCard p-3 d-flex flex-column " >
                    <div className= "d-flex justify-content-center" >
                        <img className= {props.IMGclassName +" "+ "card-img-top" }src={props.ImgSrc} alt="image by author" />
                    </div>
                    <div className="card-body text-center">
                        <h5 className={props.TitleclassName} >{props.Title}</h5>
                        <p className="card-text HText">{props.Text}</p>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Hirirng_Card