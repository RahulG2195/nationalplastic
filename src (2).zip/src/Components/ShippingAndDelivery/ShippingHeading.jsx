

const ShippingHeading = () => {
    return (
        <>

            <div className="main_container mt-5">
                <div className="text-center fw-bold">
                    <div className=" title2 fs-1 ">Purchase &<span className="fw-bold text-danger"> Return Policy</span> </div>
                </div>
            </div>
        </>
    )
}
export default ShippingHeading

