import TC from '../../Components/TC/TC'

const TermsAndConditions = () => {
    return (
        <>
            <TC />

        </>
    )
}
export default TermsAndConditions