import AddBody from "@/Components/Address/AddBody"
import AddHeader from "@/Components/Address/Adress"

const AddressPage = () => {
    return (
        <>
            <div className="main_conatiner">
                <AddHeader />
                <AddBody />
            </div>
        </>
    )
}
export default AddressPage