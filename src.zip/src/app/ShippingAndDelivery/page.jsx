import ShippingHeading from "@/Components/ShippingAndDelivery/ShippingHeading";
import ShippingBanner from "../../Components/ShippingAndDelivery/ShippingBannner";

const ShippingAndDelivery = () => {
  return (
    <>
      <ShippingBanner />
      <ShippingHeading />
    </>
  );
};
export default ShippingAndDelivery;
