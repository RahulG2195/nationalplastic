import ShippingBanner from "../../Components/ShippingAndDelivery/ShippingBannner";
import ShippingHeading from "../../Components/ShippingAndDelivery/ShippingHeading.jsx"

const ShippingAndDelivery = () => {
    return (
        <>

            <ShippingBanner />
            <ShippingHeading />

        </>
    )
}
export default ShippingAndDelivery