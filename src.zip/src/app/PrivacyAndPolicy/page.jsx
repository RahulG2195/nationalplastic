import Privacy from "../../Components/PrivacyAndPolicy/Privacy";

const PrivacyAndPolicy = () => {
  return (
    <>
      <Privacy />
    </>
  );
};
export default PrivacyAndPolicy;
