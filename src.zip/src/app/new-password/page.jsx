"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/router";
import "./PasswordPage.css";
import { useParams } from "next/navigation";
const PasswordPage = () => {
  return (
    <div className="container">
      <>Check Email</>
    </div>
  );
};

export default PasswordPage;
