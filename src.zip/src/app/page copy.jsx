

import Career from './career/page'
import News from './NewsAndMedia/Page'
import CSR from './CSR/CSR'
import Page from './PrivacyAndPolicy/Page'
import TC from './TermsAndConditions/Page'
import Wishlist from './Wishlist/Wishlist'
import ShippingAndDelivery from './ShippingAndDelivery/ShippingAndDeliver'

const page = () => {


  return (
    <>

      {/* <News /> */}

      {/* <CSR /> */}

      {/* <Career /> */}

      {/* <Page /> */}

      {/* <TC /> */}

      <Wishlist/>

      {/* <ShippingAndDelivery /> */}

    </>

  )

}

export default page
