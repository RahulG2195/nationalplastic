import WishlistPage1 from "../../Components/Wishlist/WishlistPage1"

const Wishlist = () =>{
    return(
        <>
        <WishlistPage1 />
        </>
    )
}
export default Wishlist