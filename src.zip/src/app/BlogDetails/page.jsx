import Details from "@/Components/BlogDetails/Details"
const BlogDetails = () => {
    return (
        <>
            <Details/>
        </>
    )
}
export default BlogDetails