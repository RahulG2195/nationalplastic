"use client"
import React from "react";
import Image from "next/image";



const HealthCare = () => {


    return (
        <>
            < div className="mt-5">


                <div className="text-center ">
                    <div className=" title2 fs-1">Health Care<span className="fw-bold text-danger"> Initiatives</span> </div>
                    <div className=" mt-1 fw-normal">From your living room to healthcare spaces: Our commitment to <br />
                        wellness extends as we collaborate with healthcare initiatives, providing comfort with a purpose.
                    </div>
                </div>



            </div>
        </>
    )

}
export default HealthCare; 