import '../../styles/header.css';

function TopBar() {
  return (
      <div className="row p-3 top_nav">
          <div className="col">
            <p className=''>50+ National Plastic Stores across India. Come, Visit Us!</p>
          </div>
        </div>
  )
}

export default TopBar
