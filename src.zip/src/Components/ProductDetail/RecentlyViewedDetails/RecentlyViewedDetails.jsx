"use client";
import RecentlyViewed from "@/Components/ProductsCatlogue/RecentlyViewed";
// import PreChairsCard from "@/Components/preChairsCard/PreChairsCard";
// import "@/Components/preChairsCard/preChairsCard.css";

const RecentlyViewedDetails = () => {
  return (
    <>
      <RecentlyViewed />
    </>
  );
};

export default RecentlyViewedDetails;
